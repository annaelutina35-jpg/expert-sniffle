package com.example.myapplication67;

import android.app.Activity;

public class MainActivity extends Activity {
}
