package com.example.myapplication228petrov

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var etDeposit: TextInputEditText
    private lateinit var etPercent: TextInputEditText
    private lateinit var tvDeposit: TextView
    private lateinit var tvPercent: TextView
    private lateinit var tvCommission: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvCategory: TextView
    private lateinit var cardResult: CardView

    private var currentField = "deposit" // "deposit" или "percent"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Инициализация
        etDeposit = findViewById(R.id.etDeposit)
        etPercent = findViewById(R.id.etPercent)
        tvDeposit = findViewById(R.id.tvDeposit)
        tvPercent = findViewById(R.id.tvPercent)
        tvCommission = findViewById(R.id.tvCommission)
        tvTotal = findViewById(R.id.tvTotal)
        tvCategory = findViewById(R.id.tvCategory)
        cardResult = findViewById(R.id.cardResult)

        // Установка обработчиков для цифровых кнопок
        val numberButtons = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        )

        for (id in numberButtons) {
            findViewById<Button>(id).setOnClickListener {
                val digit = (it as Button).text.toString()
                appendToCurrentField(digit)
            }
        }

        // Кнопка "."
        findViewById<Button>(R.id.btnDot).setOnClickListener {
            appendToCurrentField(".")
        }

        // Кнопка "C" (очистка последнего символа)
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            deleteLastChar()
        }

        // Кнопка "OK" (расчёт)
        findViewById<Button>(R.id.btnOk).setOnClickListener {
            calculate()
        }

        // Клик по полю для выбора активного поля
        etDeposit.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) currentField = "deposit"
        }

        etPercent.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) currentField = "percent"
        }

        // По умолчанию выбрано поле депозита
        currentField = "deposit"
        etDeposit.requestFocus()

        // Первоначальный расчёт
        calculate()
    }

    private fun appendToCurrentField(char: String) {
        val currentText = when (currentField) {
            "deposit" -> etDeposit.text.toString()
            "percent" -> etPercent.text.toString()
            else -> ""
        }

        // Запрещаем больше одной точки
        if (char == "." && currentText.contains(".")) {
            return
        }

        val newText = currentText + char

        when (currentField) {
            "deposit" -> etDeposit.setText(newText)
            "percent" -> etPercent.setText(newText)
        }

        // Перемещаем курсор в конец
        when (currentField) {
            "deposit" -> etDeposit.setSelection(newText.length)
            "percent" -> etPercent.setSelection(newText.length)
        }
    }

    private fun deleteLastChar() {
        val currentText = when (currentField) {
            "deposit" -> etDeposit.text.toString()
            "percent" -> etPercent.text.toString()
            else -> ""
        }

        if (currentText.isNotEmpty()) {
            val newText = currentText.dropLast(1)

            when (currentField) {
                "deposit" -> {
                    etDeposit.setText(newText)
                    etDeposit.setSelection(newText.length)
                }
                "percent" -> {
                    etPercent.setText(newText)
                    etPercent.setSelection(newText.length)
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun calculate() {
        val depositStr = etDeposit.text.toString().ifEmpty { "0" }
        val percentStr = etPercent.text.toString().ifEmpty { "0" }

        val deposit = depositStr.toDoubleOrNull() ?: 0.0
        val percent = percentStr.toDoubleOrNull() ?: 0.0

        val commission = deposit * (percent / 100.0)
        val total = deposit + commission

        // Определяем категорию и цвета
        val category = getCategory(percent)
        val (categoryColor, bgColor) = getCategoryColors(percent)

        // Обновляем UI
        tvDeposit.text = $$"Депозит: $${"%.2f".format(deposit)}"
        tvPercent.text = "Процент: ${"%.0f".format(percent)}%"
        tvCommission.text = "Комиссия: ${"%.2f".format(commission)}"
        tvTotal.text = "Сумма: ${"%.2f".format(total)}"
        tvCategory.text = category
        tvCategory.setTextColor(categoryColor)
        tvCategory.setBackgroundColor(bgColor)
        cardResult.setCardBackgroundColor(bgColor)
    }

    private fun getCategory(percent: Double): String {
        return when (percent) {
            in 0.0..9.0 -> "Пенсионный"
            in 10.0..14.0 -> "Оптимальный"
            in 15.0..19.0 -> "Комфорт"
            in 20.0..24.0 -> "Бизнесмен"
            else -> "Максимум"
        }
    }

    private fun getCategoryColors(percent: Double): Pair<Int, Int> {
        val (colorId, bgId) = when (percent) {
            in 0.0..9.0 -> R.color.pension to R.color.bg_pension
            in 10.0..14.0 -> R.color.optimal to R.color.bg_optimal
            in 15.0..19.0 -> R.color.comfort to R.color.bg_comfort
            in 20.0..24.0 -> R.color.business to R.color.bg_business
            else -> R.color.maximum to R.color.bg_maximum
        }
        return (getColor(colorId) to getColor(bgId))
    }
}
