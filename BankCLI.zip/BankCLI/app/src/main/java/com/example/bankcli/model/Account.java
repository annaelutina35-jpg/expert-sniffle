package com.example.bankcli.model;

public class Account {
    private String id;
    private String clientID;
    private double balance;
    private AccountType type;

    public Account(String id, String clientID, double balance, AccountType type) {
        this.id = id;
        this.clientID = clientID;
        this.balance = balance;
        this.type = type;
    }

    public String getId() { return id; }
    public String getClientID() { return clientID; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
    public AccountType getType() { return type; }

    @Override
    public String toString() {
        return String.format("[Account{ id='%s', clientID='%s', balance=%.1f }]", id, clientID, balance);
    }
}