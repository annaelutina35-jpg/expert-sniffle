package com.example.bankcli.service;

import com.example.bankcli.model.Account;
import com.example.bankcli.model.AccountType;
import com.example.bankcli.repository.AccountRepository;
import java.util.Optional;

public class TransactionService {
    private final AccountRepository repository;

    public TransactionService(AccountRepository repository) {
        this.repository = repository;
    }

    public boolean deposit(String accountId, double amount) {
        if (amount <= 0) {
            System.out.println("Amount must be positive!");
            return false;
        }
        Optional<Account> opt = repository.findById(accountId);
        if (opt.isEmpty()) {
            System.out.println("Account not found!");
            return false;
        }
        Account acc = opt.get();
        acc.setBalance(acc.getBalance() + amount);
        return true;
    }

    public boolean withdraw(String accountId, double amount) {
        if (amount <= 0) {
            System.out.println("Amount must be positive!");
            return false;
        }
        Optional<Account> opt = repository.findById(accountId);
        if (opt.isEmpty()) {
            System.out.println("Account not found!");
            return false;
        }
        Account acc = opt.get();

        if (acc.getType() == AccountType.FIXED) {
            System.out.println("Cannot withdraw from FIXED account!");
            return false;
        }

        if (acc.getBalance() < amount) {
            System.out.println("Insufficient funds!");
            return false;
        }

        acc.setBalance(acc.getBalance() - amount);
        return true;
    }
}