package com.example.bankcli.service;

import com.example.bankcli.model.Account;
import com.example.bankcli.model.AccountType;
import com.example.bankcli.repository.AccountRepository;
import java.util.List;
import java.util.Optional;

public class AccountService {
    private final AccountRepository repository;

    // Вместо @Autowired — конструктор
    public AccountService(AccountRepository repository) {
        this.repository = repository;
    }

    public Account createAccount(String clientID, AccountType type) {
        String id = repository.generateId();
        Account account = new Account(id, clientID, 0.0, type);
        repository.save(account);
        return account;
    }

    public List<Account> getAccounts(String clientID) {
        return repository.findAll();
    }

    public Optional<Account> findAccount(String id) {
        return repository.findById(id);
    }
}