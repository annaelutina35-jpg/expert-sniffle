package com.example.bankcli.delivery;

import java.util.Scanner;

public class MyCLI {
    private final Scanner scanner = new Scanner(System.in);
    public Scanner getScanner() { return scanner; }
}