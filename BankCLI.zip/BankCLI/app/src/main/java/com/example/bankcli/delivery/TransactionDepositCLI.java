package com.example.bankcli.delivery;

import com.example.bankcli.service.TransactionService;

public class TransactionDepositCLI {
    private final TransactionService transactionService;
    private final MyCLI myCLI;

    public TransactionDepositCLI(TransactionService transactionService, MyCLI myCLI) {
        this.transactionService = transactionService;
        this.myCLI = myCLI;
    }

    public void depositMoney(String clientID) {
        System.out.println("Type account ID");
        String accId = myCLI.getScanner().nextLine();

        System.out.println("Type Amount of money");
        double amount = Double.parseDouble(myCLI.getScanner().nextLine());

        if (transactionService.deposit(accId, amount)) {
            System.out.printf("%.2f$ transferred to %s account%n", amount, accId);
        } else {
            System.out.println("Deposit failed!");
        }
    }
}