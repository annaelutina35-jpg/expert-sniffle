package com.example.bankcli;

import com.example.bankcli.delivery.*;
import com.example.bankcli.repository.AccountRepository;
import com.example.bankcli.service.AccountService;
import com.example.bankcli.service.TransactionService;

public class main {
    public static void main(String[] args) {
        AccountRepository repository = new AccountRepository();
        AccountService accountService = new AccountService(repository);
        TransactionService transactionService = new TransactionService(repository);
        MyCLI myCLI = new MyCLI();

        AccountBasicCLI accountBasicCLI = new AccountBasicCLI(accountService, myCLI);
        TransactionDepositCLI depositCLI = new TransactionDepositCLI(transactionService, myCLI);
        TransactionWithdrawCLI withdrawCLI = new TransactionWithdrawCLI(transactionService, myCLI);

        boolean running = true;
        String clientID = "1";

        String helpMessage = "1 - show accounts\n2 - create account\n3 - deposit\n4 - withdraw\n5 - transfer\n6 - this message\n7 - exit\n";

        System.out.print("Welcome to CLI bank service\n");
        System.out.print("Enter operation number: \n");
        System.out.print(helpMessage);

        while (running) {
            String input = myCLI.getScanner().nextLine();
            switch (input) {
                case "1": accountBasicCLI.getAccounts(clientID); break;
                case "2": accountBasicCLI.createAccountRequest(clientID); break;
                case "3": depositCLI.depositMoney(clientID); break;
                case "4": withdrawCLI.withdrawMoney(clientID); break;
                case "6": System.out.print(helpMessage); break;
                case "7": System.out.print("Application Closed\n"); running = false; break;
                default: System.out.print("Command not recognized!\n"); break;
            }
        }
        myCLI.getScanner().close();
    }
}