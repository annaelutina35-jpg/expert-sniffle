package com.example.bankcli.model;

public enum AccountType {
    CHECKING,
    SAVING,
    FIXED
}
