package com.example.bankcli.repository;

import com.example.bankcli.model.Account;
import java.util.*;

public class AccountRepository {
    private final Map<String, Account> accounts = new HashMap<>();
    private int nextId = 1;

    public String generateId() {
        return String.format("%03d%06d", 1, nextId++);
    }

    public void save(Account account) {
        accounts.put(account.getId(), account);
    }

    public Optional<Account> findById(String id) {
        return Optional.ofNullable(accounts.get(id));
    }

    public List<Account> findAll() {
        return new ArrayList<>(accounts.values());
    }
}