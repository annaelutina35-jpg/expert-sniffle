package com.example.bankcli.delivery;

import com.example.bankcli.service.TransactionService;

public class TransactionWithdrawCLI {
    private final TransactionService transactionService;
    private final MyCLI myCLI;

    public TransactionWithdrawCLI(TransactionService transactionService, MyCLI myCLI) {
        this.transactionService = transactionService;
        this.myCLI = myCLI;
    }

    public void withdrawMoney(String clientID) {
        System.out.println("Type account ID");
        String accId = myCLI.getScanner().nextLine();

        System.out.println("Type Amount of money");
        double amount = Double.parseDouble(myCLI.getScanner().nextLine());

        if (transactionService.withdraw(accId, amount)) {
            System.out.printf("%.2f$ transferred from %s account%n", amount, accId);
        } else {
            System.out.println("Withdraw failed!");
        }
    }
}