package com.example.bankcli.delivery;

import com.example.bankcli.model.Account;
import com.example.bankcli.model.AccountType;
import com.example.bankcli.service.AccountService;
import java.util.Scanner;

public class AccountBasicCLI {
    private final AccountService accountService;
    private final MyCLI myCLI;

    public AccountBasicCLI(AccountService accountService, MyCLI myCLI) {
        this.accountService = accountService;
        this.myCLI = myCLI;
    }

    public void getAccounts(String clientID) {
        System.out.println("Accounts for client " + clientID + ":");
        accountService.getAccounts(clientID).forEach(System.out::println);
    }

    public void createAccountRequest(String clientID) {
        System.out.println("Choose account type");
        System.out.println("[CHECKING, SAVING, FIXED]");

        Scanner scanner = myCLI.getScanner();
        String typeStr = scanner.nextLine().toUpperCase();

        try {
            AccountType type = AccountType.valueOf(typeStr);
            Account acc = accountService.createAccount(clientID, type);
            System.out.println("Bank account created");
            System.out.println(acc);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid account type!");
        }
    }
}